CREATE TABLE employee (
    id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    salary DECIMAL(10, 2)
);

INSERT INTO employee (id, first_name, last_name, email, salary) VALUES (1, 'Ana', 'Martínez', 'ana.martinez@example.com', 4500.00);
INSERT INTO employee (id, first_name, last_name, email, salary) VALUES (2, 'Luis', 'Gómez', 'luis.gomez@example.com', 5200.50);
INSERT INTO employee (id, first_name, last_name, email, salary) VALUES (3, 'Carla', 'Rodríguez', 'carla.rodriguez@example.com', 6100.75);
INSERT INTO employee (id, first_name, last_name, email, salary) VALUES (4, 'Diego', 'Fernández', 'diego.fernandez@example.com', 4300.00);
INSERT INTO employee (id, first_name, last_name, email, salary) VALUES (5, 'Sofía', 'Pérez', 'sofia.perez@example.com', 4800.25);

SELECT salary, email ,first_name FROM employee WHERE salary>:salary;